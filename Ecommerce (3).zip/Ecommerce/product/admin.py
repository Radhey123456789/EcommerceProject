from django.contrib import admin
from product.models import *
# Register your models here.
admin.site.register(Categories)
admin.site.register(Product)
admin.site.register(Cart)

